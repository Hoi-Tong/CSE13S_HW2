4. Explain your answers (15 points)

Please answer the following questions for each file you wrote as part of this assignment.

1. Printing patterns
"Why This Works" Explanation: Explain the underlying logic and reasoning that makes your code solve the problem. 
Focus on the core concepts and principles your solution utilizes.

I made a nested for loop. One that loop through each line and how many sybols it needs. 
The another one is inside the pervious for loop, and it loop through the symbols horizonally 
on the same line. The variable of the inner for loop is depended on the variable of the outer 
for loop, so evrytime the outter for loop increase its value, the inner for loop will need to 
print the amount of the symbols of that value. This is how different lines print out different
 amount of the symbols, which created a triangle in different direction.


2. Arithmetic calculator
"Why This Works" Explanation: Explain the underlying logic and reasoning that makes your code solve the problem. 
Focus on the core concepts and principles your solution utilizes.

I used a while loop to keep the program running until it runs into a false condition. I 
also used break and continue function to stop the loop or go back to the top of the while 
loop if a condition is met. I also used a lot of if statements to check did a certain 
condition met (like when num2 is 0 and operation is %) and I need to stop or go back to the top of the loop. 


3. Lockers
"Why This Works" Explanation: Explain the underlying logic and reasoning that makes your code solve the problem. 
Focus on the core concepts and principles your solution utilizes.

I used recurive function to keep the recuring the function until the base case was met. I 
put the base case as t=1 because all the lockers are open when t=1. Then, I put a recuring 
if and else statement to keep does l % k == 0 to see will the student open or close a 
certain locker. It also call back the function to recurse it.

